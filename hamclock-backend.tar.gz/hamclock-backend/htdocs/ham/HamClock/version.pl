#!/usr/bin/env perl
use strict;
use warnings;

print "Content-Type: text/plain; charset=ISO-8859-1\r\n\r\n";
print "4.22\n";
print "No info for version  4.22\n";


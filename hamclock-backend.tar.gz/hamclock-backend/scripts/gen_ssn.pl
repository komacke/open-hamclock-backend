#!/usr/bin/env perl
use strict;
use warnings;

use LWP::UserAgent;
use File::Basename qw(dirname);
use File::Path qw(make_path);
use File::Temp qw(tempfile);
use File::Copy qw(copy);
use File::Spec;

my $URL = 'https://services.swpc.noaa.gov/text/daily-solar-indices.txt';
my $OUT = '/opt/hamclock-backend/htdocs/ham/HamClock/ssn/ssn-31.txt';

my $TMPDIR = '/opt/hamclock-backend/tmp';

# Ensure TMPDIR exists
if (!-d $TMPDIR) {
    make_path($TMPDIR, { mode => 0755 })
      or die "ERROR: failed to create $TMPDIR: $!\n";
}
die "ERROR: TMPDIR not writable: $TMPDIR\n" unless -w $TMPDIR;

# Ensure output directory exists
my $out_dir = dirname($OUT);
if (!-d $out_dir) {
    make_path($out_dir, { mode => 0755 })
      or die "ERROR: failed to create $out_dir: $!\n";
}
die "ERROR: output dir not writable: $out_dir\n" unless -w $out_dir;

my $ua = LWP::UserAgent->new(
    timeout => 15,
    agent   => 'hamclock-ssn-noaa/1.1',
);

# Load existing data (if any)
my %by_date;
if (-f $OUT) {
    open my $in, '<', $OUT or die "ERROR: cannot read $OUT: $!\n";
    while (my $line = <$in>) {
        chomp $line;
        if ($line =~ /^(\d{4}\s+\d{2}\s+\d{2})\s+(\d+)/) {
            $by_date{$1} = $2;
        }
    }
    close $in or die "ERROR: close($OUT) failed: $!\n";
}

# Fetch NOAA data
my $res = $ua->get($URL);
die "ERROR: failed to fetch NOAA data: " . $res->status_line . "\n"
    unless $res->is_success;

my $parsed = 0;
for my $line (split /\n/, $res->decoded_content) {
    # YYYY MM DD <flux> <sunspot> ...
    if ($line =~ /^\s*(\d{4})\s+(\d{2})\s+(\d{2})\s+\d+\s+(\d+)/) {
        my ($y,$m,$d,$ssn) = ($1,$2,$3,$4);
        my $date = sprintf("%04d %02d %02d", $y,$m,$d);
        $by_date{$date} = $ssn;
        $parsed++;
    }
}
die "ERROR: NOAA parse failed (0 rows)\n" if $parsed == 0;

# Sort by date and keep last 31
my @dates = sort keys %by_date;
@dates = @dates[-31 .. -1] if @dates > 31;

# Step 1: write content to a temp file in /opt/hamclock-backend/tmp
my ($tfh, $tpath) = tempfile('ssn-31_XXXXXX', DIR => $TMPDIR, UNLINK => 0);
for my $d (@dates) {
    print {$tfh} "$d $by_date{$d}\n";
}
close $tfh or die "ERROR: close(temp) failed: $!\n";

# Step 2: copy into output dir as a sibling temp file, then rename atomically
my ($ofh, $opath) = tempfile('ssn-31_XXXXXX', DIR => $out_dir, UNLINK => 0);
close $ofh or die "ERROR: close(out-temp-handle) failed: $!\n";  # will copy over it

copy($tpath, $opath) or die "ERROR: copy($tpath -> $opath) failed: $!\n";

rename($opath, $OUT) or die "ERROR: rename($opath -> $OUT) failed: $!\n";

# Best-effort cleanup of the staging temp file in TMPDIR
unlink $tpath;

exit 0;

